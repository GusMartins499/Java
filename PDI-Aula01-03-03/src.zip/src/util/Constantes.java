package util;

public class Constantes {

	public static final int VIZINHOS3X3 = 1;
	public static final int VIZINHOSCRUZ = 2;
	public static final int VIZINHOSX = 3;
	public static final int CANALR = 1;
	public static final int CANALG = 2;
	public static final int CANALB = 3;
}
