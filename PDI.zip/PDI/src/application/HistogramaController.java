package application;

import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;

public class HistogramaController {

	@FXML
	public BarChart<String, Number> grafico1;
	@FXML
	public BarChart<String, Number> grafico2;
	@FXML
	public BarChart<String, Number> grafico3;
}
